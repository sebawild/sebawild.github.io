/**
 * This class represents the Odds distribution.
 * Enter your solution below.
 *
 * @author George Skretas
 * @author Sebastian Wild
 */


import java.util.LinkedList;
import java.util.Queue;

public class BambooOdds extends Bamboo {


	private static final int subtaskId = 3;
	private static final int[] growthRate = new int[]{3, 3, 3, 5, 5, 7, 7, 9};

	public static void main(String[] args) {
		Queue<Integer> solution = new LinkedList<Integer>();
		// Dont change anything above this line
		// ==========================
		
		String username = "george"; //Change this to your username
		solution.add(0); // Add your solution here. Your solution should consist of numbers that are fed to a periodic queue, e.g. 0,1.
		
		// ==========================
		// Dont change anything below this line
		Bamboo A = new Bamboo();
		A.calculateRatio(growthRate, solution, username, subtaskId);
	}

}
