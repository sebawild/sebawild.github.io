# Insert your username here:
MWS_username = 'MWS_USERNAME'
