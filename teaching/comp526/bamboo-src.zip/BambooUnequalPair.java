/**
 * This class represents the Unequal Pair distribution.
 * Enter your solution below.
 *
 * @author George Skretas
 * @author Sebastian Wild
 */

import java.util.LinkedList;
import java.util.Queue;

public class BambooUnequalPair extends Bamboo {

	private static final int subtaskId = 1;
	private static final int[] growthRate = new int[]{1, 199};

	public static void main(String[] args) {
		Queue<Integer> solution = new LinkedList<Integer>();
		// Dont change anything over this line
		// ==========================
		
		String username = "george"; //Change this to your username
		solution.add(0); // Add your solution here. Your solution should consist of numbers that are fed to a periodic queue, e.g. 0,1.
		
		// ==========================
		// Dont change anything under this line
		Bamboo A = new Bamboo();
		A.calculateRatio(growthRate, solution, username, subtaskId);
	}

}
