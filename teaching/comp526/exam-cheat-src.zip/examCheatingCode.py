# Compute the honking protocol for the exam cheaters

def compute_and_send_code(exam):
    code = [0] * 10
    # Don't change anything above this line
    # ==========================

    # TODO Add your solution here.

    # ==========================
    # Don't change anything below this line
    return code


def enter_solution_based_on_code(code):
    answer = [0] * 20
    # Don't change anything above this line
    # ==========================

    # TODO Add your solution here.

    # ==========================
    # Don't change anything below this line
    return answer



