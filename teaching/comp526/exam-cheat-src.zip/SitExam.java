import java.util.Arrays;

/**
 * Main class to take the exam; it computes the worst possible grade when
 * using the protocol implemented in ExamCheatingCode.
 *
 * @author George Skretas
 * @author Sebastian Wild
 */
public class SitExam {

	public static void main(String[] args) {
		int[] exam = new int[20];
		int minGrade = 20;
		ExamCheatingCode protocol = new ExamCheatingCode();
		while (Arrays.stream(exam).anyMatch(i -> i == 0)) {
			int grade = 0;
			int[] code = protocol.computeAndSendTheCode(exam); // return 10 bit based on exam solution
			int[] answers = protocol.enterSolutionBasedOnCode(code); // return the answers to the test
			for (int i = 0; i < 20; i++)  // check how many answers are correct
				if (answers[i] == exam[i]) grade++;
			if (grade < minGrade) minGrade = grade;
			increment(exam); // generate next exam
		}
		System.out.println(minGrade);
	}

	private static void increment(int[] bits) {
		for (int i = 0; i < 20; i++) {
			if (bits[i] == 0) {
				bits[i]++;
				return;
			} else {
				bits[i] = 0;
			}
		}
	}
}
    

