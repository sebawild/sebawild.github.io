/**
 * This class represents the Powers3 distribution.
 * Enter your solution below.
 *
 * @author George Skretas
 * @author Sebastian Wild
 */

import java.util.LinkedList;
import java.util.Queue;


public class BambooPowers3 extends Bamboo {

	private static final int[] growthRate = new int[]{3, 6, 12, 24, 48, 96, 192, 386};
	private static final int subtaskId = 5;

	public static void main(String[] args) {
		Queue<Integer> solution = new LinkedList<Integer>();
		// Dont change anything above this line
		// ==========================
		
		String username = "george"; //Change this to your username
		solution.add(0); // Add your solution here. Your solution should consist of numbers that are fed to a periodic queue, e.g. 0,1.
		
		// ==========================
		// Dont change anything under this line
		Bamboo A = new Bamboo();
		A.calculateRatio(growthRate, solution, username, subtaskId);
	}

}
