# Compute the honking protocol for the exam cheaters

def compute_and_send_code(exam):
    code = [0] * 10
    # Dont change anything above this line
    # ==========================

    # TODO Add your solution here.

    # ==========================
    # Dont change anything below this line
    return code


def enter_solution_based_on_code(code):
    answer = [0] * 20
    # Dont change anything above this line
    # ==========================

    # TODO Add your solution here.

    # ==========================
    # Dont change anything below this line
    return answer



