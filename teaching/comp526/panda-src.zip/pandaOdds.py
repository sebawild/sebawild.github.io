import panda
plot = panda.BambooPlot(
    'Odds',
    [9, 7, 7, 5, 5, 3, 3]
)

# Don't change anything above this line
# ===================================

# generate your solution as a list of indices
queue = [0, 1]

# ====================================
# Dont change anything below this line

# records your solution
plot.simulate(queue)
