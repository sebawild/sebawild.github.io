import collections
import math
from typing import List
import config

if config.MWS_username == "MWS_USERNAME":
    raise Exception("Please enter your MWS username in config.py")

resultsFile = f"{config.MWS_username}-results.txt"


class BambooPlot:

    def __init__(self, name, growthRates):
        self.name = name
        self.growthRates = growthRates

    def simulate(self, solution: List[int],
                 iterations: int = 100000):
        guaranteedHarvest = guaranteed_harvest(self.growthRates, solution,
                                               iterations)
        print(f'{self.name} guaranteedHarvest={guaranteedHarvest}')
        try:
            write_results(self.name, guaranteedHarvest)
        except Exception as e:
            print(f"Could not save result to {resultsFile}: {e}")


def write_dict(dict):
    with open(resultsFile, 'w', encoding="utf-8") as file:
        for k in sorted(dict.keys()):
            file.writelines(f'{k}={dict[k]}')
            file.write('\n')


# read dictionary from file
def read_dict():
    dict = {}
    try:
        with open(resultsFile, 'r', encoding="utf-8") as file:
            for line in file:
                if '=' in line:
                    key, value = line.split('=')
                    dict[key] = value.strip()
    except FileNotFoundError:
        pass
    return dict


def write_results(plotName: str, guaranteedHarvest: int):
    results = read_dict()
    results[plotName] = guaranteedHarvest
    write_dict(results)


def guaranteed_harvest(growthRates: List[int], solution: List[int], iterations: int = 100000):
    queue = collections.deque(solution)
    k = len(growthRates)
    guaranteedHarvest = math.inf
    heights = k * [math.inf]
    for i in range(iterations):
        toCut = queue.popleft()
        queue.append(toCut)
        guaranteedHarvest = min(guaranteedHarvest, heights[toCut])
        heights[toCut] = 0
        for j in range(0, k):
            heights[j] += growthRates[j]
    return guaranteedHarvest


