/**
 * Protocol to cheat on exam
 *
 * @author George Skretas
 * @author Sebastian Wild
 */


public class ExamCheatingCode {

    public int[] computeAndSendTheCode(int[] exam) {
		int[] code = new int[10];
		// Dont change anything above this line
		// ==========================

	    // TODO Add your solution here.

		// ==========================
		// Dont change anything below this line        
		return code;
	}

    public int[] enterSolutionBasedOnCode(int[] code) {
		int[] answer = new int[20];

		// Dont change anything above this line
		// ==========================

	    // TODO Add your solution here.

		// ==========================
		// Dont change anything below this line
		return answer;
	}
}
