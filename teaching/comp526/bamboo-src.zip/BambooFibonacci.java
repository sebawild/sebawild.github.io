/**
 * This class represents the Fibonacci distribution.
 * Enter your solution below.
 *
 * @author George Skretas
 * @author Sebastian Wild
 */


import java.util.LinkedList;
import java.util.Queue;

public class BambooFibonacci extends Bamboo {

	private static final int subtaskId = 4;
	private static final int[] growthRate = new int[]{1, 1, 2, 3, 5, 8, 13, 21};

	public static void main(String[] args) {
		Queue<Integer> solution = new LinkedList<Integer>();
		// Dont change anything above this line
		// ==========================
		
		String username = "george"; //Change this to your username
		solution.add(0); // Add your solution here. Your solution should consist of numbers that are fed to a periodic queue, e.g. 0,1.
		
		// ==========================
		// Dont change anything under this line
		Bamboo main = new Bamboo();
		main.calculateRatio(growthRate, solution, username, subtaskId);
	}

}
